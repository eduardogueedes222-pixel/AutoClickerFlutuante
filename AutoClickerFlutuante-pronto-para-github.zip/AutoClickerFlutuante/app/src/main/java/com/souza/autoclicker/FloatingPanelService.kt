package com.souza.autoclicker

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private lateinit var params: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var intervalMs = 100L
    private var tapX = 540f
    private var tapY = 960f
    private lateinit var status: TextView
    private lateinit var intervalInput: EditText
    private lateinit var xInput: EditText
    private lateinit var yInput: EditText
    private val clickLoop = object : Runnable {
        override fun run() {
            if (!running) return
            val service = TapAccessibilityService.instance
            if (service != null) {
                service.tapAt(tapX, tapY)
            } else {
                status.text = "Ative Acessibilidade"
                running = false
                return
            }
            handler.postDelayed(this, intervalMs.coerceAtLeast(40L))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) showPanel()
        return START_NOT_STICKY
    }

    private fun showPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 12)
            setBackgroundColor(0xF01A1D24.toInt())
        }
        val headerRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val header = TextView(this).apply {
            text = "☰  AUTO CLICKER"
            textSize = 15f
            setTextColor(0xFFB7FF2A.toInt())
            setPadding(6, 8, 6, 12)
        }
        val close = Button(this).apply {
            text = "✕"
            setOnClickListener { stopSelf() }
        }
        headerRow.addView(header, LinearLayout.LayoutParams(0, 48, 1f))
        headerRow.addView(close, LinearLayout.LayoutParams(48, 48))
        status = TextView(this).apply {
            text = "● PARADO"
            textSize = 12f
            setTextColor(0xFFFF7777.toInt())
            setPadding(6, 0, 6, 8)
        }
        intervalInput = EditText(this).apply {
            setSingleLine(true)
            setText("100")
            hint = "Intervalo (ms)"
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFBBBBBB.toInt())
        }
        xInput = EditText(this).apply {
            setSingleLine(true); setText("540"); hint = "X"; textSize = 13f
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFFBBBBBB.toInt())
        }
        yInput = EditText(this).apply {
            setSingleLine(true); setText("1200"); hint = "Y"; textSize = 13f
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFFBBBBBB.toInt())
        }
        val coordRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        coordRow.addView(xInput, LinearLayout.LayoutParams(0, 48, 1f))
        coordRow.addView(yInput, LinearLayout.LayoutParams(0, 48, 1f))
        val start = Button(this).apply {
            text = "INICIAR"
            setOnClickListener {
                intervalMs = intervalInput.text.toString().toLongOrNull()?.coerceAtLeast(40L) ?: 100L
                tapX = xInput.text.toString().toFloatOrNull() ?: 540f
                tapY = yInput.text.toString().toFloatOrNull() ?: 1200f
                if (TapAccessibilityService.instance == null) {
                    status.text = "Ative Acessibilidade"
                    status.setTextColor(0xFFFF7777.toInt())
                } else {
                    running = true
                    status.text = "● EXECUTANDO · ${intervalMs} ms"
                    status.setTextColor(0xFFB7FF2A.toInt())
                    handler.removeCallbacks(clickLoop)
                    handler.post(clickLoop)
                }
            }
        }
        val stop = Button(this).apply {
            text = "PARAR"
            setOnClickListener {
                running = false
                handler.removeCallbacks(clickLoop)
                status.text = "● PARADO"
                status.setTextColor(0xFFFF7777.toInt())
            }
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(start, LinearLayout.LayoutParams(0, 48, 1f))
        actions.addView(stop, LinearLayout.LayoutParams(0, 48, 1f))
        val hint = TextView(this).apply {
            text = "Toque X/Y em pixels · mínimo 40 ms"
            textSize = 10f
            setTextColor(0xFFCCCCCC.toInt())
            setPadding(4, 4, 4, 0)
        }
        root.addView(headerRow)
        root.addView(status)
        root.addView(intervalInput, LinearLayout.LayoutParams(-1, 48))
        root.addView(coordRow)
        root.addView(actions)
        root.addView(hint)

        params = WindowManager.LayoutParams(
            280,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 18
            y = 140
        }

        // Arraste pelo cabeçalho para mover o mini painel.
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    try { wm.updateViewLayout(root, params) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
        panel = root
        wm.addView(root, params)
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(clickLoop)
        if (panel != null) {
            try { wm.removeView(panel) } catch (_: Exception) {}
            panel = null
        }
        super.onDestroy()
    }
}
