package com.souza.autoclicker

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(0xFF101216.toInt())
        }
        val title = TextView(this).apply {
            text = "AUTO CLICKER\nFLUTUANTE"
            textSize = 26f
            gravity = Gravity.CENTER
            setTextColor(0xFFB7FF2A.toInt())
        }
        val info = TextView(this).apply {
            text = "Mini painel móvel para tocar automaticamente na tela.\n\n1. Autorize a sobreposição.\n2. Ative o serviço de Acessibilidade.\n3. Abra o painel flutuante."
            textSize = 16f
            setTextColor(0xFFE8E8E8.toInt())
            setPadding(0, 24, 0, 24)
        }
        val overlay = Button(this).apply {
            text = "1 · Autorizar janela flutuante"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }
        }
        val access = Button(this).apply {
            text = "2 · Abrir Acessibilidade"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val launch = Button(this).apply {
            text = "3 · Abrir mini painel"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, FloatingPanelService::class.java))
                }
            }
        }
        listOf(title, info, overlay, access, launch).forEach {
            root.addView(it, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 14 })
        }
        setContentView(root)
    }
}
